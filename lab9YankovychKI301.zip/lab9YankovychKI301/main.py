from Motorboat import Motorboat




if __name__ == '__main__':
    motorboat = Motorboat()
    motorboat.lwequal()
    motorboat.SetAnotherColor("Yellow")
    motorboat.SubVeslo_lenght()
    motorboat.AddVeslo_lenght()
    motorboat.BimBimBamBam()
    motorboat.NoBimBimBamBam()
    motorboat.Direction("Назад")
    motorboat.WeightChanger(44)
    motorboat.WaterChanger(13)
    motorboat.BaggageRemove()
    motorboat.BaggageAdder()
    motorboat.PassengersChanger(52)
    motorboat.StartMotor()
    motorboat.StopMotor()
    motorboat.BenzWaste()

