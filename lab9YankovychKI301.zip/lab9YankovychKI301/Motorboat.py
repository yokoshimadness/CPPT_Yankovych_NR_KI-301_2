from Rowingboat import Rowingboat

#class Motorboat
class Motorboat(Rowingboat):
    def __init__(self):
        super().__init__()
        self.__benz = 150
    def StartMotor(self):
        print("\nМотор ввімкнено")
    def StopMotor(self):
        print("\nМотор вимкнено")
    def Set_Benz(self,xbenz):
        print("Зміна кількості бенза")
        self.__benz=xbenz
    def getBenz(self):
        print("Отримання кількості бенза")
        return self.__benz
    def BenzWaste(self):
        print("\nВиклик трати бензина на 50 л.")
        print("Бенз до:" + str(self.__benz))
        if self.__benz >=50:
            self.__benz=self.__benz-50
            print("Бенз після:" + str(self.__benz))
        else:
            print("Помилка: Недостатньо бензина для виконання.")

