#class Characteristics
class Characteristics:
    def __init__(self):
        self.__lenght = 15
        self.__width = 125
        self.__color = "blue"
        self.__veslo_lenght = 23
    def Set_Lenght(self,xlenght):
        self.__lenght = xlenght
    def Set_Width(self,xwidth):
        self.__width = xwidth
    def Set_Color(self,xcolor):
        self.__color=xcolor
    def Set_Veslo_Lenght(self,xveslo_lenght):
        self.__veslo_lenght=xveslo_lenght
    def getLenght(self):
        return self.__lenght
    def getWidth(self):
        return self.__width
    def getColor(self):
        return self.__color
    def getVeslo_Lenght(self):
        return self.__veslo_lenght