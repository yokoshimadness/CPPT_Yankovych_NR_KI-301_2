from Characteristics import Characteristics
from State import State
from Functions import Functions

#class Rowingboat
class Rowingboat:
    def __init__(self):
        self.__characteristics = Characteristics()
        self.__state = State()
        self.__functions = Functions()
    def lwequal(self):
        print("\nВиклик прирівнювання довжини до ширини")
        print("Довжина була:" + str(self.__characteristics.getLenght())+"Довжина стала:" + str(self.__characteristics.getWidth()))
        self.__characteristics.Set_Lenght(self.__characteristics.getWidth())
    def wlequal(self):
        print("\nВиклик прирівнювання ширини до довжини")
        print("Ширина була:" + str(self.__characteristics.getWidth())+"Ширина стала:" + str(self.__characteristics.getLenght()))
        self.__characteristics.Set_Width(self.__characteristics.getLenght())
    def SetAnotherColor(self,xcolor):
        print("\nВиклик зміни кольору")
        print("Колір був:"+str(self.__characteristics.getColor())+" Колір став:"+str(xcolor))
        self.__characteristics.Set_Color(xcolor)
    def SubVeslo_lenght(self):
        print("\nВиклик зменшення довжини весла на 1")
        print("Довжина весла до:"+ str(self.__characteristics.getVeslo_Lenght()))
        a = self.__characteristics.getVeslo_Lenght()
        a=a-1
        self.__characteristics.Set_Veslo_Lenght(a)
        print("Довжина весла після:"+ str(self.__characteristics.getVeslo_Lenght()))

    def AddVeslo_lenght(self):
        print("\nВиклик збільшення довжини весла на 1")
        print("Довжина весла до:" + str(self.__characteristics.getVeslo_Lenght()))
        a = self.__characteristics.getVeslo_Lenght()
        a = a + 1
        self.__characteristics.Set_Veslo_Lenght(a)
        print("Довжина весла після:" + str(self.__characteristics.getVeslo_Lenght()))
    def BimBimBamBam(self):
        print("Виклик ламання шлюпки")
        print("Шлюпка підбита: " + str(self.__state.getDamaged()))
        self.__state.Set_Damaged(True)
        print("Шлюпка підбита: " + str(self.__state.getDamaged()))
    def NoBimBimBamBam(self):
        print("Виклик ремонту шлюпки")
        print("Шлюпка підбита: " + str(self.__state.getDamaged()))
        self.__state.Set_Damaged(False)
        print("Шлюпка підбита: " + str(self.__state.getDamaged()))
    def Direction(self,xdir):
        print("\nВиклик зміни напрямку руху")
        print("Напрямок руху до:" + str(self.__state.getDirection()))
        self.__state.Set_Direction(xdir)
        print("Напрямок руху після:" + str(self.__state.getDirection()) )
    def WeightChanger(self,xweight):
        print("\nВиклик зміни ваги")
        print("Вантажність до:" + str(self.__functions.getWeightcan()))
        self.__functions.Set_Weightcan(xweight)
        print("Вантажність після:" + str(self.__functions.getWeightcan()))
    def WaterChanger(self,xwater):
        print("Виклик зміни плавучості")
        print("Плавучість до:" + str(self.__functions.getWaterspec()) + "%")
        self.__functions.Set_Waterspec(xwater)
        print("Плавучість після:" + str(self.__functions.getWaterspec()) + "%")
    def BaggageRemove(self):
        print("\nВиклик усунення місця для багажу")
        print("Місце для багажу є:" + str(self.__functions.getBaggageplace()))
        self.__functions.Set_Baggageplace(False)
        print("Місце для багажу є:" + str(self.__functions.getBaggageplace()))
    def BaggageAdder(self):
        print("\nВиклик додавання місця для багажу")
        print("Місце для багажу є:" + str(self.__functions.getBaggageplace()))
        self.__functions.Set_Baggageplace(True)
        print("Місце для багажу є:" + str(self.__functions.getBaggageplace()))
    def PassengersChanger(self,xCount):
        print("\nВиклик зміни кількості місць для пасажирів")
        print("\nКількість місць до:" + str(self.__functions.getPassengersCounter()))
        self.__functions.Set_Passengerscounter(xCount)
        print("\nКількість місць після:" + str(self.__functions.getPassengersCounter()))