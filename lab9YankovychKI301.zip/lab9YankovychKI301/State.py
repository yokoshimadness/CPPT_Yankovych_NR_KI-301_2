#class State
class State:
    def __init__(self):
        self.__damaged = False
        self.__direction = "Прямо"
    def Set_Damaged(self,xdamaged):
        self.__damaged=xdamaged
    def Set_Direction(self,xDir):
        self.__direction=xDir
    def getDamaged(self):
        return self.__damaged
    def getDirection(self):
        return self.__direction
