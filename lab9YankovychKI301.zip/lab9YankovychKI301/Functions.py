#class Functions
class Functions:
    def __init__(self):
        self.__weightcan=15
        self.__waterspec=15
        self.__baggageplace=True
        self.__passengerscounter=44
    def Set_Weightcan(self,xweightcan):
        self.__weightcan=xweightcan
    def Set_Waterspec(self,xwaterspec):
        self.__waterspec=xwaterspec
    def Set_Baggageplace(self,xbaggageplace):
        self.__baggageplace=xbaggageplace
    def Set_Passengerscounter(self,xpassengerscounter):
        self.__passengerscounter=xpassengerscounter
    def getWeightcan(self):
        return self.__weightcan
    def getWaterspec(self):
        return self.__waterspec
    def getBaggageplace(self):
        return self.__baggageplace
    def getPassengersCounter(self):
        return self.__passengerscounter
